
<?php $__env->startSection('titulo'); ?>
    Usuarios
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<div class="md:flex justify-center ">
    <table class="border rounded-sm shadow-2xl">
        <thead class="border-b font-medium dark:border-neutral-500">
            <tr>
              <th scope="col" class="px-6 py-4">Cedula</th>
              <th scope="col" class="px-6 py-4">Nombre</th>
              <th scope="col" class="px-6 py-4">telefono</th>
              <th scope="col" class="px-6 py-4">email</th> 
              <th scope="col" class="px-6 py-4" colspan="2">Opciones</th> 
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-gray-100 border-b">
                    <td class="px-6 py-4"><?php echo e($item->cedula); ?></td>
                    <td class="px-6 py-4"><?php echo e($item->name); ?></td>
                    <td class="px-6 py-4"><?php echo e($item->telefono); ?></td>
                    <td class="px-6 py-4"><?php echo e($item->correo); ?></td>
                    <td class="flex px-6 py-4">
                        <a href="/actualizar-User/<?php echo e($item->id); ?>" class="btn p-2 bg-sky-600 rounded-2xl mx-2"><img class="w-4" src="<?php echo e(asset('img/editar.svg')); ?>" alt="" srcset=""></a>
                        <a href="" class="btn p-2 bg-red-600 rounded-2xl"><img class="w-4" src="<?php echo e(asset('img/basura.svg')); ?>" alt="" srcset=""></a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrudLaravel\resources\views/auth/listar.blade.php ENDPATH**/ ?>