<?php $__env->startSection('titulo'); ?>
    CRUD BASICO
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    <div class="flex  flex-row">
        <p>Regsitra Los Usuarios o preciona el boton de listar usuarios para verlos</p>
        <button class="btn bg-slate-500 p-5 rounded-xl"><a href="/listar-Users">Listar Usuarios</a></button>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\CrudLaravel\resources\views/welcome.blade.php ENDPATH**/ ?>